/* ====== SHARED VARS ====== */

var ua                  = navigator.userAgent,
    isiPhone            = false,
    isiPad              = false,
    isiPod              = false,
    isAndroidPhone      = false,
    android             = false,
    iOS                 = false,
    isIE                = false,
    ieMobile            = false,
    isSafari            = false,
    isMac               = false,
    // useful logs in the console
    globalDebug         = false;

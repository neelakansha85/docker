<svg width="24px" height="29px" viewBox="0 0 24 29">
    <g id="cart-box" transform="translate(1, 1)" fill="none">
        <path stroke="currentColor" stroke-width="2" d="M5.0,5 L2,5 C0.89,5 0,5.89 0,6 L0,25 C0,26.11 0.89,27 2,27 L20,27 C21.11,27 22,26.1 22,25 L22,7 C22,5.89 21.1,5 20,5 L16.9,5 C16.44,2.16 13.973,0 11,0 C8,0 5.559,2.1623 5,5 Z" stroke-linecap="square"></path>
        <rect x="5" y="4" width="12" height="2" fill="currentColor" stroke-width="0"></rect>
    </g>
</svg>